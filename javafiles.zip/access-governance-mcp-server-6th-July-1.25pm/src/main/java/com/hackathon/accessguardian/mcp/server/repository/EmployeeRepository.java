package com.hackathon.accessguardian.mcp.server.repository;

import com.hackathon.accessguardian.mcp.server.domain.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {
    List<Employee> findByDepartment(String department);
    List<Employee> findByRole(String role);
    List<Employee> findByLineManagerId(String lineManagerId);
    Optional<Employee> findByName(String name);
    Optional<Employee> findByEmployeeId(String employeeId);
}

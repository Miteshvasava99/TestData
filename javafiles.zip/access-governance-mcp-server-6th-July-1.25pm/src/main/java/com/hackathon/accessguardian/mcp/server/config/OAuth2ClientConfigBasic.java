package com.hackathon.accessguardian.mcp.server.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.*;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class OAuth2ClientConfigBasic {

  @Bean
  WebClient webClient(ReactiveClientRegistrationRepository clientRegistrations) {
    // Use an in-memory service to manage authorized clients
    var authorizedClientService = new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrations);

    // Create a manager that handles the client credentials flow automatically
    var authorizedClientManager = new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(
            clientRegistrations, authorizedClientService);

    // Create the filter function with the manager
    var oauth2 = new ServerOAuth2AuthorizedClientExchangeFilterFunction(authorizedClientManager);

    // The registration name 'data-source-api' must match the one in application.yml
    oauth2.setDefaultClientRegistrationId("data-source-api");

    return WebClient.builder()
            .filter(oauth2)
            .build();
  }
}


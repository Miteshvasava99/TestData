package com.hackathon.accessguardian.mcp.server.service.dataingestion;

import com.hackathon.accessguardian.mcp.server.domain.*;
import com.hackathon.accessguardian.mcp.server.external.*;
import com.hackathon.accessguardian.mcp.server.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers; // Import the Schedulers class

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExternalDataIngestionService {

    private final WebClient webClient; // Injected WebClient configured for OAuth2
    private final DataTransformerEnhanced dataTransformer;
    private final EmployeeRepository employeeRepository;
    private final GroupRepository groupRepository;
    private final GroupMembershipRepository groupMembershipRepository;
    private final AccessChangeLogRepository accessChangeLogRepository;
    private final AccessAnomalyRepository accessAnomalyRepository;

    @Value("${spring.external-services.employee-api-url}")
    private String employeeApiUrl;
    @Value("${spring.external-services.group-api-url}")
    private String groupApiUrl;
    @Value("${spring.external-services.group-membership-api-url}")
    private String groupMembershipApiUrl;
    @Value("${spring.external-services.access-change-log-api-url}")
    private String accessChangeLogApiUrl;
    @Value("${spring.external-services.access-anomaly-api-url}")
    private String accessAnomalyApiUrl;


    // --- Scheduled Tasks for Data Ingestion ---

    @Scheduled(cron = "${schedules.employee-fetch:0 0 * * *?}") // Example with default value
    public void fetchEmployeeData() {
        log.info("Scheduled task: Fetching employee data from external API.");
        webClient.get()
                .uri(employeeApiUrl)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<ExternalEmployeeDto>>() {})
                .map(dtos -> dtos.stream()
                        .map(dataTransformer::toEmployeeEntity)
                        .collect(Collectors.toList()))
                .flatMap(employees -> Mono.fromCallable(() -> {
                                    log.info("Saving {} employees.", employees.size());
                                    return employeeRepository.saveAll(employees);
                                })
                                .subscribeOn(Schedulers.boundedElastic()) // Execute blocking call on a dedicated thread
                )
                .doOnError(e -> log.error("Error fetching or saving employee data: {}", e.getMessage(), e))
                .subscribe(savedEmployees -> log.info("Successfully ingested {} employees.", savedEmployees.size()));
    }

    @Scheduled(cron = "${schedules.group-fetch:0 0 0 * *?}")
    public void fetchGroupData() {
        log.info("Scheduled task: Fetching group data from external API.");
        webClient.get()
                .uri(groupApiUrl)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<ExternalGroupDto>>() {})
                .map(dtos -> dtos.stream()
                        .map(dataTransformer::toGroupEntity)
                        .collect(Collectors.toList()))
                .flatMap(groups -> Mono.fromCallable(() -> {
                                    log.info("Saving {} groups.", groups.size());
                                    return groupRepository.saveAll(groups);
                                })
                                .subscribeOn(Schedulers.boundedElastic())
                )
                .doOnError(e -> log.error("Error fetching or saving group data: {}", e.getMessage(), e))
                .subscribe(savedGroups -> log.info("Successfully ingested {} groups.", savedGroups.size()));
    }

    @Scheduled(cron = "${schedules.group-membership-fetch:0 */30 * * *?}")
    public void fetchGroupMembershipData() {
        log.info("Scheduled task: Fetching group membership data from external API.");
        webClient.get()
                .uri(groupMembershipApiUrl)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<ExternalGroupMembershipDto>>() {})
                .map(dtos -> dtos.stream()
                        .map(dataTransformer::toGroupMembershipEntity)
                        .collect(Collectors.toList()))
                .flatMap(memberships -> Mono.fromCallable(() -> {
                                    log.info("Saving {} group memberships.", memberships.size());
                                    return groupMembershipRepository.saveAll(memberships);
                                })
                                .subscribeOn(Schedulers.boundedElastic())
                )
                .doOnError(e -> log.error("Error fetching or saving group membership data: {}", e.getMessage(), e))
                .subscribe(savedMemberships -> log.info("Successfully ingested {} group memberships.", savedMemberships.size()));
    }

    @Scheduled(cron = "${schedules.access-change-log-fetch:0 */15 * * *?}")
    public void fetchAccessChangeLogData() {
        log.info("Scheduled task: Fetching access change log data from external API.");
        webClient.get()
                .uri(accessChangeLogApiUrl)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<ExternalAccessChangeLogDto>>() {})
                .map(dtos -> dtos.stream()
                        .map(dataTransformer::toAccessChangeLogEntity)
                        .collect(Collectors.toList()))
                .flatMap(logs -> Mono.fromCallable(() -> {
                                    log.info("Saving {} access change logs.", logs.size());
                                    return accessChangeLogRepository.saveAll(logs);
                                })
                                .subscribeOn(Schedulers.boundedElastic())
                )
                .doOnError(e -> log.error("Error fetching or saving access change log data: {}", e.getMessage(), e))
                .subscribe(savedLogs -> log.info("Successfully ingested {} access change logs.", savedLogs.size()));
    }

    @Scheduled(cron = "${schedules.access-anomaly-fetch:0 0 */6 * *?}")
    public void fetchAccessAnomalyData() {
        log.info("Scheduled task: Fetching access anomaly data from external API.");
        webClient.get()
                .uri(accessAnomalyApiUrl)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<ExternalAccessAnomalyDto>>() {})
                .map(dtos -> dtos.stream()
                        .map(dataTransformer::toAccessAnomalyEntity)
                        .collect(Collectors.toList()))
                .flatMap(anomalies -> Mono.fromCallable(() -> {
                                    log.info("Saving {} access anomalies.", anomalies.size());
                                    return accessAnomalyRepository.saveAll(anomalies);
                                })
                                .subscribeOn(Schedulers.boundedElastic())
                )
                .doOnError(e -> log.error("Error fetching or saving access anomaly data: {}", e.getMessage(), e))
                .subscribe(savedAnomalies -> log.info("Successfully ingested {} access anomalies.", savedAnomalies.size()));
    }
}
package com.hackathon.accessguardian.mcp.server.service.dataingestion;

import com.hackathon.accessguardian.mcp.server.domain.*;
import com.hackathon.accessguardian.mcp.server.external.*;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class DataTransformerEnhanced {

    // Define date/datetime formatters based on your external API's JSON date strings
    // IMPORTANT: Adjust these formatters to match the actual format of dates/timestamps
    // in the JSON responses from your external REST services.
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE; // e.g., "YYYY-MM-DD"
    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME; // e.g., "YYYY-MM-DDTHH:MM:SS"

    public Employee toEmployeeEntity(ExternalEmployeeDto dto) {
        if (dto == null) {
            return null;
        }
        Employee employee = new Employee();
        employee.setEmployeeId(dto.getId());
        employee.setName(dto.getFullName());
        employee.setDepartment(dto.getDeptName());
        employee.setRole(dto.getJobTitle());
        employee.setLineManagerId(dto.getManagerId());
        // Example parsing, adjust based on actual format
        employee.setJoinDate(LocalDate.parse(dto.getHireDate(), DATE_FORMATTER));
        // Note: lineManagerName, currentGroupMemberships, directReports are @Transient in Employee
        // and will be populated by AccessGovernanceService's Get_Employee_Context_Graph tool if needed.
        return employee;
    }

    public Group toGroupEntity(ExternalGroupDto dto) {
        if (dto == null) {
            return null;
        }
        Group group = new Group();
        group.setGroupId(dto.getGroupId());
        group.setGroupName(dto.getGroupDisplayName());
        group.setDescription(dto.getGroupDescription());
        group.setResourceType(dto.getResourceAccessType());
        return group;
    }

    public GroupMembership toGroupMembershipEntity(ExternalGroupMembershipDto dto) {
        if (dto == null) {
            return null;
        }
        GroupMembership membership = new GroupMembership();
        // ID is auto-generated, so set to null
        membership.setEmployeeId(dto.getEmployeeIdentifier());
        membership.setGroupId(dto.getGroupIdentifier());
        membership.setAssignedDate(LocalDate.parse(dto.getAssignmentDate(), DATE_FORMATTER));
        if (dto.getRemovalDate()!= null &&!dto.getRemovalDate().isEmpty()) {
            membership.setRevokedDate(LocalDate.parse(dto.getRemovalDate(), DATE_FORMATTER));
        }
        membership.setAssignedBy(dto.getAssignedBySource());
        return membership;
    }

    public AccessChangeLog toAccessChangeLogEntity(ExternalAccessChangeLogDto dto) {
        if (dto == null) {
            return null;
        }
        AccessChangeLog log = new AccessChangeLog();
        // ID is auto-generated, so set to null
        log.setEmployeeId(dto.getUserId());
        log.setGroupId(dto.getAccessGroupId());
        log.setChangeType(dto.getChangeAction());
        log.setChangeDate(LocalDateTime.parse(dto.getTimestamp(), DATETIME_FORMATTER)); // Example parsing
        log.setChangedBy(dto.getActor());
        log.setReason(dto.getReasonForChange());
        return log;
    }

    public AccessAnomaly toAccessAnomalyEntity(ExternalAccessAnomalyDto dto) {
        if (dto == null) {
            return null;
        }
        AccessAnomaly anomaly = new AccessAnomaly();
        // ID is auto-generated, so set to null
        anomaly.setEmployeeId(dto.getUserId());
        anomaly.setAnomalyType(dto.getType());
        anomaly.setDescription(dto.getDetails());
        anomaly.setDetectedDate(LocalDateTime.parse(dto.getDetectionTime(), DATETIME_FORMATTER)); // Example parsing
        anomaly.setScore(dto.getAnomalyScore());
        anomaly.setStatus(dto.getCurrentStatus());
        return anomaly;
    }
}

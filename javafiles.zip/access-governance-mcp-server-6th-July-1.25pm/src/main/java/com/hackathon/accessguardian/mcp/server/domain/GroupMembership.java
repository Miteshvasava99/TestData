package com.hackathon.accessguardian.mcp.server.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupMembership {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Primary key for this entity
    private String employeeId;
    private String groupId;
    private LocalDate assignedDate;
    private LocalDate revokedDate; // Null if still active
    private String assignedBy; // e.g., "HR", "IT", "Self-service"
}

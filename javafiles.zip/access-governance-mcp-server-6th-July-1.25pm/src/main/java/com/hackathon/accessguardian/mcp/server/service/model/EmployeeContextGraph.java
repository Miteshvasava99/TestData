package com.hackathon.accessguardian.mcp.server.service.model;

import com.hackathon.accessguardian.mcp.server.domain.Employee;
import com.hackathon.accessguardian.mcp.server.domain.GroupMembership;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

// This POJO is designed to provide a rich, nested structure for the LLM
// to perform "Tree-of-Thoughts" like reasoning over the employee's context.
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeContextGraph {
    private Employee employeeDetails;
    private Employee lineManagerDetails;
    private List<Employee> directReports;
    private List<Employee> peerEmployeesInSameRoleAndDept;
    private List<GroupMembership> currentGroupMemberships;
}
package com.hackathon.accessguardian.mcp.server.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "AccessGroup") // Renamed to avoid conflict with Java's Group
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Group {
    @Id
    private String groupId;
    private String groupName;
    private String description;
    private String resourceType; // e.g., "Application", "SharePoint", "NetworkShare"
}

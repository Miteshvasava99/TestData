package com.hackathon.accessguardian.mcp.server.repository;

import com.hackathon.accessguardian.mcp.server.domain.GroupMembership;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface GroupMembershipRepository extends JpaRepository<GroupMembership, Long> {
    List<GroupMembership> findByEmployeeId(String employeeId);
    List<GroupMembership> findByGroupId(String groupId);
    Optional<GroupMembership> findByEmployeeIdAndGroupIdAndRevokedDateIsNull(String employeeId, String groupId);
    List<GroupMembership> findByEmployeeIdAndAssignedDateBetween(String employeeId, LocalDate startDate, LocalDate endDate);
    List<GroupMembership> findByEmployeeIdAndRevokedDateIsNull(String employeeId); // Added for convenience
}

package com.hackathon.accessguardian.mcp.server.repository;

import com.hackathon.accessguardian.mcp.server.domain.AccessChangeLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AccessChangeLogRepository extends JpaRepository<AccessChangeLog, Long> {
    List<AccessChangeLog> findByEmployeeId(String employeeId);
    List<AccessChangeLog> findByEmployeeIdAndChangeDateBetween(String employeeId, LocalDateTime startDate, LocalDateTime endDate);
    List<AccessChangeLog> findByGroupId(String groupId);
}

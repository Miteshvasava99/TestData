package com.hackathon.accessguardian.mcp.server.service;


import com.hackathon.accessguardian.mcp.server.domain.*;
import com.hackathon.accessguardian.mcp.server.repository.*;
import com.hackathon.accessguardian.mcp.server.service.model.AccessReviewSummary;
import com.hackathon.accessguardian.mcp.server.service.model.EmployeeContextGraph;
import com.hackathon.accessguardian.mcp.server.service.model.PolicyDriftReport;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccessGovernanceService {

    private final EmployeeRepository employeeRepository;
    private final GroupRepository groupRepository;
    private final GroupMembershipRepository groupMembershipRepository;
    private final AccessChangeLogRepository accessChangeLogRepository;
    private final AccessAnomalyRepository accessAnomalyRepository;

    // --- Basic Data Retrieval Tools ---

    @Tool(name = "Get_Employee_Details", description = "Retrieve full details for an employee by their employee ID. Input: employeeId (String).")
    public Employee getEmployeeDetails(String employeeId) {
        log.info("Retrieving details for employee: {}", employeeId);
        return employeeRepository.findByEmployeeId(employeeId).orElse(null);
    }

    @Tool(name = "Get_Employee_Details_by_Name", description = "Retrieve full details for an employee by their name. Returns a list of employees if multiple match. Input: name (String).")
    public List<Employee> getEmployeeDetailsByName(String name) {
        log.info("Retrieving details for employee by name: {}", name);
        return employeeRepository.findByName(name).map(List::of).orElse(List.of()); // Assuming name is unique enough for single result or return empty list
    }

    @Tool(name = "Get_Direct_Reports", description = "Get a list of direct reports for a given line manager's employee ID. Input: lineManagerId (String).")
    public List<Employee> getDirectReports(String lineManagerId) {
        log.info("Retrieving direct reports for manager: {}", lineManagerId);
        return employeeRepository.findByLineManagerId(lineManagerId);
    }

    @Tool(name = "Get_Department_Employees", description = "Get a list of all employees in a specific department. Input: department (String).")
    public List<Employee> getDepartmentEmployees(String department) {
        log.info("Retrieving employees in department: {}", department);
        return employeeRepository.findByDepartment(department);
    }

    @Tool(name = "Get_Employee_Group_Memberships", description = "Get all active group memberships for a specific employee by their employee ID. Input: employeeId (String).")
    public List<GroupMembership> getEmployeeGroupMemberships(String employeeId) {
        log.info("Retrieving group memberships for employee: {}", employeeId);
        return groupMembershipRepository.findByEmployeeIdAndRevokedDateIsNull(employeeId);
    }

    @Tool(name = "Get_Group_Members", description = "Get a list of all employee IDs who are members of a specific group. Input: groupId (String).")
    public List<String> getGroupMembers(String groupId) {
        log.info("Retrieving members for group: {}", groupId);
        return groupMembershipRepository.findByGroupId(groupId).stream()
                .map(GroupMembership::getEmployeeId)
                .collect(Collectors.toList());
    }

    @Tool(name = "Get_Group_Details", description = "Retrieve details for a specific access group by its group ID. Input: groupId (String).")
    public Group getGroupDetails(String groupId) {
        log.info("Retrieving details for group: {}", groupId);
        return groupRepository.findByGroupId(groupId).orElse(null);
    }

    @Tool(name = "Get_Historical_Access_Changes", description = "Retrieve historical access changes (assignments/revocations) for an employee within a date range. Input: employeeId (String), startDate (YYYY-MM-DD), endDate (YYYY-MM-DD).")
    public List<AccessChangeLog> getHistoricalAccessChanges(String employeeId, LocalDate startDate, LocalDate endDate) {
        log.info("Retrieving historical access changes for employee {} between {} and {}", employeeId, startDate, endDate);
        return accessChangeLogRepository.findByEmployeeIdAndChangeDateBetween(employeeId, startDate.atStartOfDay(), endDate.atTime(23, 59, 59));
    }

    // --- Tools for "Tree-of-Thoughts" structured output / Analytical Support ---

    @Tool(name = "Get_Employee_Context_Graph",
            description = "Retrieves a comprehensive context graph for an employee, including their details, line manager, direct reports, peers in the same department/role, and their current group memberships. This is designed for complex analytical tasks. Input: employeeId (String).")
    public EmployeeContextGraph getEmployeeContextGraph(String employeeId) {
        log.info("Generating context graph for employee: {}", employeeId);
        Optional<Employee> employeeOpt = employeeRepository.findByEmployeeId(employeeId);
        if (employeeOpt.isEmpty()) {
            return null;
        }
        Employee employee = employeeOpt.get();

        // Populate line manager name
        if (employee.getLineManagerId()!= null) {
            employeeRepository.findByEmployeeId(employee.getLineManagerId())
                    .ifPresent(manager -> employee.setLineManagerName(manager.getName()));
        }

        List<Employee> directReports = employeeRepository.findByLineManagerId(employeeId);
        List<Employee> peers = employeeRepository.findByDepartment(employee.getDepartment()).stream()
                .filter(e ->!e.getEmployeeId().equals(employeeId) && e.getRole().equals(employee.getRole()))
                .collect(Collectors.toList());

        List<GroupMembership> currentMemberships = groupMembershipRepository.findByEmployeeIdAndRevokedDateIsNull(employeeId);

        // For direct reports and peers, also fetch their current group memberships for richer context
        directReports.forEach(dr -> dr.setCurrentGroupMemberships(groupMembershipRepository.findByEmployeeIdAndRevokedDateIsNull(dr.getEmployeeId())));
        peers.forEach(p -> p.setCurrentGroupMemberships(groupMembershipRepository.findByEmployeeIdAndRevokedDateIsNull(p.getEmployeeId())));

        return new EmployeeContextGraph(
                employee,
                employee.getLineManagerId()!= null? employeeRepository.findByEmployeeId(employee.getLineManagerId()).orElse(null) : null,
                directReports,
                peers,
                currentMemberships
        );
    }

    @Tool(name = "Get_Peer_Group_Memberships_by_Role_and_Department",
            description = "Retrieves active group memberships for employees who share the same role and department as a specified employee. Useful for peer-based access analysis. Input: employeeId (String).")
    public List<GroupMembership> getPeerGroupMembershipsByRoleAndDepartment(String employeeId) {
        log.info("Retrieving peer group memberships for employee: {}", employeeId);
        Optional<Employee> employeeOpt = employeeRepository.findByEmployeeId(employeeId);
        if (employeeOpt.isEmpty()) {
            return List.of();
        }
        Employee employee = employeeOpt.get();

        List<Employee> peers = employeeRepository.findByDepartment(employee.getDepartment()).stream()
                .filter(e ->!e.getEmployeeId().equals(employeeId) && e.getRole().equals(employee.getRole()))
                .collect(Collectors.toList());

        List<GroupMembership> peerMemberships = new ArrayList<>();
        for (Employee peer : peers) {
            peerMemberships.addAll(groupMembershipRepository.findByEmployeeIdAndRevokedDateIsNull(peer.getEmployeeId()));
        }
        return peerMemberships;
    }

    @Tool(name = "Detect_Access_Anomalies",
            description = "Flags employees with unusual access patterns for their role/team based on historical data and peer comparisons. Returns a list of detected anomalies. Input: employeeId (String).")
    public List<AccessAnomaly> detectAccessAnomalies(String employeeId) {
        log.info("Detecting access anomalies for employee: {}", employeeId);
        // In a real system, this would trigger an ML model (e.g., Isolation Forest, Autoencoder)
        // For this example, we'll return some dummy anomalies if the employee exists.
        if (employeeRepository.existsById(employeeId)) {
            List<AccessAnomaly> anomalies = new ArrayList<>();
            // Example dummy anomaly: if employee has "Admin" role but no "Admin" group
            Optional<Employee> empOpt = employeeRepository.findByEmployeeId(employeeId);
            if (empOpt.isPresent() && empOpt.get().getRole().contains("Admin")) {
                List<GroupMembership> currentGroups = groupMembershipRepository.findByEmployeeIdAndRevokedDateIsNull(employeeId);
                boolean hasAdminGroup = currentGroups.stream().anyMatch(gm -> groupRepository.findById(gm.getGroupId()).map(Group::getGroupName).orElse("").contains("Admin"));
                if (!hasAdminGroup) {
                    anomalies.add(new AccessAnomaly(null, employeeId, "Missing_Admin_Group_for_Admin_Role",
                            "Employee with Admin role does not have a corresponding Admin group membership.",
                            LocalDateTime.now(), 0.8, "Detected"));
                }
            }
            // Example dummy anomaly: too many groups compared to peers
            List<GroupMembership> employeeGroups = groupMembershipRepository.findByEmployeeIdAndRevokedDateIsNull(employeeId);
            List<GroupMembership> peerGroups = getPeerGroupMembershipsByRoleAndDepartment(employeeId);
            long distinctPeerGroups = peerGroups.stream().map(GroupMembership::getGroupId).distinct().count();
            if (employeeGroups.size() > (distinctPeerGroups / 2) + 5) { // Arbitrary threshold
                anomalies.add(new AccessAnomaly(null, employeeId, "Excessive_Group_Memberships",
                        "Employee has significantly more group memberships than typical peers in the same role/department.",
                        LocalDateTime.now(), 0.7, "Detected"));
            }
            return anomalies;
        }
        return List.of();
    }

    @Tool(name = "Generate_Access_Review_Summary",
            description = "Generates a summary for a manager during access audits, highlighting discrepancies in access compared to peers. Input: employeeId (String).")
    public AccessReviewSummary generateAccessReviewSummary(String employeeId) {
        log.info("Generating access review summary for employee: {}", employeeId);
        Optional<Employee> employeeOpt = employeeRepository.findByEmployeeId(employeeId);
        if (employeeOpt.isEmpty()) {
            return null;
        }
        Employee employee = employeeOpt.get();

        List<GroupMembership> employeeMemberships = groupMembershipRepository.findByEmployeeIdAndRevokedDateIsNull(employeeId);
        List<GroupMembership> peerMemberships = getPeerGroupMembershipsByRoleAndDepartment(employeeId);

        Map<String, Long> peerGroupCounts = peerMemberships.stream()
                .collect(Collectors.groupingBy(GroupMembership::getGroupId, Collectors.counting()));

        List<AccessReviewSummary.GroupDiscrepancy> discrepancies = new ArrayList<>();
        for (GroupMembership empMembership : employeeMemberships) {
            long count = peerGroupCounts.getOrDefault(empMembership.getGroupId(), 0L);
            if (count == 0) {
                groupRepository.findById(empMembership.getGroupId()).ifPresent(group ->
                        discrepancies.add(new AccessReviewSummary.GroupDiscrepancy(
                                group.getGroupName(),
                                "Employee has access, but no peers in same role/department do.",
                                "Excessive"
                        ))
                );
            } else {
                // Example: if less than 5% of peers have it, flag as unusual
                long totalPeers = employeeRepository.findByDepartment(employee.getDepartment()).stream()
                        .filter(e -> e.getRole().equals(employee.getRole())).count();
                if (totalPeers > 0 && (double) count / totalPeers < 0.05) {
                    groupRepository.findById(empMembership.getGroupId()).ifPresent(group ->
                            discrepancies.add(new AccessReviewSummary.GroupDiscrepancy(
                                    group.getGroupName(),
                                    String.format("Employee has access, but only %d%% of peers in this role/department do.", (int) ((double) count / totalPeers * 100)),
                                    "Unusual"
                            ))
                    );
                }
            }
        }

        return new AccessReviewSummary(employee.getName(), employee.getRole(), employee.getDepartment(), discrepancies);
    }

    @Tool(name = "Detect_Policy_Drift",
            description = "Detects if group memberships for a specific group have drifted over time compared to a baseline. Returns a report of added and removed members. Input: groupId (String), baselineDate (YYYY-MM-DD).")
    public PolicyDriftReport detectPolicyDrift(String groupId, LocalDate baselineDate) {
        log.info("Detecting policy drift for group {} since baseline {}", groupId, baselineDate);
        Optional<Group> groupOpt = groupRepository.findById(groupId);
        if (groupOpt.isEmpty()) {
            return null;
        }
        Group group = groupOpt.get();

        List<GroupMembership> currentMemberships = groupMembershipRepository.findByGroupId(groupId).stream()
                .filter(gm -> gm.getRevokedDate() == null || gm.getRevokedDate().isAfter(LocalDate.now()))
                .collect(Collectors.toList());
        List<GroupMembership> baselineMemberships = groupMembershipRepository.findByGroupId(groupId).stream()
                .filter(gm -> gm.getAssignedDate().isBefore(baselineDate) && (gm.getRevokedDate() == null || gm.getRevokedDate().isAfter(baselineDate)))
              .collect(Collectors.toList());

        List<String> addedMembers = currentMemberships.stream()
                .filter(cm -> baselineMemberships.stream().noneMatch(bm -> bm.getEmployeeId().equals(cm.getEmployeeId())))
                .map(GroupMembership::getEmployeeId)
                .collect(Collectors.toList());

        List<String> removedMembers = baselineMemberships.stream()
                .filter(bm -> currentMemberships.stream().noneMatch(cm -> cm.getEmployeeId().equals(bm.getEmployeeId())))
                .map(GroupMembership::getEmployeeId)
                .collect(Collectors.toList());

        return new PolicyDriftReport(group.getGroupName(), baselineDate, addedMembers, removedMembers);
    }

    // Helper method to simulate initial data for H2
    public void initializeData() {
        // Employees

        Employee emp1 = new Employee("emp001", "Alice Johnson", "Engineering", "Software Engineer", LocalDate.of(2022, 1, 15), "mgr001",true,null,null,null);
        Employee emp2 = new Employee("emp002", "Bob Williams", "Engineering", "Software Engineer", LocalDate.of(2022, 3, 10), "mgr001", true,null, null,null);
        Employee emp3 = new Employee("emp003", "Charlie Brown", "Marketing", "Marketing Specialist", LocalDate.of(2023, 2, 1), "mgr002", true,null, null,null);
        Employee emp4 = new Employee("emp004", "Diana Prince", "Marketing", "Marketing Specialist", LocalDate.of(2023, 5, 20), "mgr002",false, null, null,null);
        Employee emp5 = new Employee("emp005", "Eve Adams", "HR", "HR Generalist", LocalDate.of(2021, 8, 1), "mgr003", true,null, null,null);
        Employee mgr1 = new Employee("mgr001", "Frank White", "Engineering", "Engineering Manager", LocalDate.of(2020, 1, 1), "exec001",false, null, null,null);
        Employee mgr2 = new Employee("mgr002", "Grace Lee", "Marketing", "Marketing Manager", LocalDate.of(2021, 6, 1), "exec001",true, null, null,null);
        Employee mgr3 = new Employee("mgr003", "Henry Green", "HR", "HR Manager", LocalDate.of(2019, 10, 1), "exec001", true,null, null,null);
        Employee exec1 = new Employee("exec001", "Ivy King", "Executive", "CEO", LocalDate.of(2018, 1, 1), null, true,null, null,null);

        employeeRepository.saveAll(List.of(emp1, emp2, emp3, emp4, emp5, mgr1, mgr2, exec1));

        // Groups
        Group g1 = new Group("grp001", "Engineering_Dev_Tools", "Access to core development tools for engineers", "Application");
        Group g2 = new Group("grp002", "Marketing_Campaign_Access", "Access to marketing campaign management platforms", "Application");
        Group g3 = new Group("grp003", "HR_Confidential_Data", "Access to sensitive HR employee data", "Application");
        Group g4 = new Group("grp004", "All_Employees_VPN", "VPN access for all employees", "Network");
        Group g5 = new Group("grp005", "Engineering_Leads", "Access for engineering managers to team dashboards", "Application");
        Group g6 = new Group("grp006", "Marketing_Analytics", "Access to marketing analytics dashboards", "Application");
        Group g7 = new Group("grp007", "Finance_Reporting", "Access to financial reporting systems", "Application"); // Not directly used by current employees

        groupRepository.saveAll(List.of(g1, g2, g3, g4, g5, g6, g7));

        // Group Memberships
        // Alice (emp001) - Eng
        groupMembershipRepository.save(new GroupMembership(null, "emp001", "grp001", LocalDate.of(2022, 1, 15), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp001", "grp004", LocalDate.of(2022, 1, 15), null, "IT"));

        // Bob (emp002) - Eng
        groupMembershipRepository.save(new GroupMembership(null, "emp002", "grp001", LocalDate.of(2022, 3, 10), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp002", "grp004", LocalDate.of(2022, 3, 10), null, "IT"));

        // Charlie (emp003) - Marketing
        groupMembershipRepository.save(new GroupMembership(null, "emp003", "grp002", LocalDate.of(2023, 2, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp003", "grp004", LocalDate.of(2023, 2, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp003", "grp006", LocalDate.of(2023, 2, 1), null, "IT"));

        // Diana (emp004) - Marketing
        groupMembershipRepository.save(new GroupMembership(null, "emp004", "grp002", LocalDate.of(2023, 5, 20), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp004", "grp004", LocalDate.of(2023, 5, 20), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp004", "grp006", LocalDate.of(2023, 5, 20), null, "IT"));

        // Eve (emp005) - HR
        groupMembershipRepository.save(new GroupMembership(null, "emp005", "grp003", LocalDate.of(2021, 8, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp005", "grp004", LocalDate.of(2021, 8, 1), null, "IT"));

        // Frank (mgr001) - Eng Manager
        groupMembershipRepository.save(new GroupMembership(null, "mgr001", "grp001", LocalDate.of(2020, 1, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr001", "grp004", LocalDate.of(2020, 1, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr001", "grp005", LocalDate.of(2020, 1, 1), null, "IT")); // Eng Leads group

        // Grace (mgr002) - Marketing Manager
        groupMembershipRepository.save(new GroupMembership(null, "mgr002", "grp002", LocalDate.of(2021, 6, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr002", "grp004", LocalDate.of(2021, 6, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr002", "grp006", LocalDate.of(2021, 6, 1), null, "IT"));

        // Henry (mgr003) - HR Manager (Not explicitly added, but can be inferred)
        groupMembershipRepository.save(new GroupMembership(null, "mgr003", "grp003", LocalDate.of(2019, 10, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr003", "grp004", LocalDate.of(2019, 10, 1), null, "IT"));

        // Ivy (exec001) - CEO
        groupMembershipRepository.save(new GroupMembership(null, "exec001", "grp004", LocalDate.of(2018, 1, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "exec001", "grp007", LocalDate.of(2018, 1, 1), null, "IT")); // Finance Reporting for CEO

        // Simulate some access changes for policy drift
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp001", "grp001", "ASSIGN", LocalDateTime.of(2022, 1, 15, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp001", "grp001", "REVOKE", LocalDateTime.of(2024, 1, 15, 9, 0), "IT", "Role change"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp001", "grp005", "ASSIGN", LocalDateTime.of(2024, 1, 15, 9, 0), "IT", "Promoted to lead"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp002", "grp001", "ASSIGN", LocalDateTime.of(2022, 3, 10, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp003", "grp002", "ASSIGN", LocalDateTime.of(2023, 2, 1, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp004", "grp002", "ASSIGN", LocalDateTime.of(2023, 5, 20, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp005", "grp003", "ASSIGN", LocalDateTime.of(2021, 8, 1, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "mgr001", "grp005", "ASSIGN", LocalDateTime.of(2020, 1, 1, 9, 0), "IT", "Manager role"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "mgr002", "grp006", "ASSIGN", LocalDateTime.of(2021, 6, 1, 9, 0), "IT", "Manager role"));
    }
}

package com.hackathon.accessguardian.mcp.server;

import com.hackathon.accessguardian.mcp.server.service.AccessGovernanceService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.ToolCallbacks; // Correct import for ToolCallbacks utility
import java.util.List;
import java.util.Arrays; // Needed if ToolCallbacks.from() returns an array and you need a List

@SpringBootApplication
public class AccessGovernanceMcpServerApplication {

    public static void main(String args) {
        SpringApplication.run(AccessGovernanceMcpServerApplication.class, args);
    }

    @Bean
    public List<ToolCallback> mcpTools(AccessGovernanceService accessGovernanceService) {
        // Use ToolCallbacks.from() to automatically discover and wrap all @Tool annotated methods
        // from the AccessGovernanceService bean.
        // This method returns a ToolCallback, which we convert to a List.
        return Arrays.asList(ToolCallbacks.from(accessGovernanceService));
    }

    @Bean
    public CommandLineRunner initData(AccessGovernanceService accessGovernanceService) {
        return args -> {
            accessGovernanceService.initializeData();
            System.out.println("Dummy access governance data initialized.");
        };
    }
}

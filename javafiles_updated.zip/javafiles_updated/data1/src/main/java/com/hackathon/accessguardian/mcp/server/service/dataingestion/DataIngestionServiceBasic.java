package com.hackathon.accessguardian.mcp.server.service.dataingestion;

import com.hackathon.accessguardian.mcp.server.repository.EmployeeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
// Other imports for repositories, transformer, etc.

@Service
public class DataIngestionServiceBasic {

    private static final Logger log = LoggerFactory.getLogger(DataIngestionServiceBasic.class);
    private final WebClient webClient;
    private final DataTransformerBasic dataTransformerBasic;
    private final EmployeeRepository employeeRepository;
    //... other repositories

    // Base URL of the external data source API modify this
    private final String employeeDataUrl = "https://api.externaldata.com/v1/employees";

    public DataIngestionServiceBasic(WebClient webClient, DataTransformerBasic dataTransformerBasic, EmployeeRepository employeeRepository) {
        this.webClient = webClient;
        this.dataTransformerBasic = dataTransformerBasic;
        this.employeeRepository = employeeRepository;
    }

    // Run every 4 hours. cron = "0 0 */4 * * *"
    @Scheduled(fixedDelay = 4 * 60 * 60 * 1000)
    public void ingestGovernanceData() {
        log.info("Starting data ingestion task...");
        try {
            // Fetch employee data
            webClient.get()
                    .uri(employeeDataUrl)
                    .retrieve()
                    .bodyToMono(String.class) // Assuming the API returns a JSON string
                    .subscribe(jsonPayload -> {
                        log.info("Successfully fetched employee data.");
                        var employees = dataTransformerBasic.transformEmployees(jsonPayload);
                        employeeRepository.saveAll(employees);
                        log.info("Saved {} employee records.", employees.size());
                    });

            //... repeat for other data types (departments, groups, etc.)

            log.info("Data ingestion task completed.");
        } catch (Exception e) {
            log.error("Error during data ingestion task", e);
        }
    }
}
